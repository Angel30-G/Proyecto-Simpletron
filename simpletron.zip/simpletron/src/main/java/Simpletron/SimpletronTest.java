/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Simpletron;

/**
 *
 * @author gabri
 */
public class SimpletronTest {
    public SimpletronTest() {
    }

    public static void main(String[] args) {
        run();
    }

    public static void run() {
        Simpletron s = new Simpletron();
        s.run();
    }
}
